<?php if (!defined('FLUX_ROOT')) exit; ?>
<?php
	$enablerss = true;
	$news = "http://onigiri-gamers.com/forum/index.php?app=core&module=global&section=rss&type=forums&id=7";
?>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
					</div>
					</div>
					</div>	
				<div class="containerbgbottom"></div>
				<div class="newsandupdates">
				<?php include ('main/news.php'); ?>
				</div>
				<div class="clear"></div>
				<div class="footer" style="margin-left:16px;">
					<div class="footerspacer"></div>
					<div class="footercreditsdiv">
						<div class="credits">
							<a href="https://www.facebook.com/pages/Zhao-Designs-and-RO-Services/1579192285632548?fref=ts"><img style="margin-left:30px; margin-top:-40px;" src="<?php echo $this->themePath('img/zhaologo.png') ?>" title="Designed and Coded By : Zhao Chow"/></a>
							<div class="clear"></div>
						</div>
						<div class="copyright">Copyright (C) 2014 <b>Onigiri Ragnarok Online</b><br/>
						All other copyrights and trademarks are property of Gravity, and their respective owners.
					</div>
						<div class="footerlogo">
						</div>
						<div class="clear"></div>
					</div>
				</div>
				</div>
			</div>
		</div>
	</body>
</html>