<?php if (!defined('FLUX_ROOT')) exit; ?>
<div class="flashshow">
<img src="<?php echo $this->themePath('img/imageslide.png') ?>" />
</div>

<div class="centerinfo">
<div class="contentinfo">
<table width="100%" border="0">
<tr>
<td style="color:#663300; font-size:10px;">
OnigiriRO offer you a High Rate Server can give you a<br />
couple of Intense and Immense gameplay. This is your<br />
invitation to get the chance to have the real gaming<br />
experience in the world of Ragnarok.
</td>
</tr>
</table>


<table width="100%" border="0" style="margin-top:20px;">
<tr>
<td style="color:#663300; font-size:10px;">
We make sure that the server is equipped with<br />
experience staff to keep improving and upgrading our<br />
gaming system. Compared to other server, we aim to<br />
give you beyond the usual experience. Build a family<br />
and promote camaraderie among players. See you in<br />
game and you'll surely be glad to be playing in Onigiri<br />
Ragnarok Online! Lets bring the smile to every player.<br />
See You!
</td>
</tr>
</table>
</div>
</div>

<div class="itemmall">
<?php include('itemmall.php'); ?>
</div>