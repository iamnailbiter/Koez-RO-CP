<?php if (!defined('FLUX_ROOT')) exit; ?>
<?php
		
//SQL Connection
function Connection()
{
$db_host="localhost"; //insert the IP Address of your website
$db_name="ragnarok"; //insert your database name insid the 2 double quotesS
$username="ragnarok"; //insert the username of your phpmyadmin (SQL username)
$password="ragnarok"; //insert the password of your phpmyadmin (SQL password)
$con=mysql_connect($db_host,$username,$password);
mysql_select_db($db_name, $con);

if(!$con)
{
echo "Connection failed!"; 
}
}

Connection();
$hpsql = mysql_query("SELECT * FROM cp_highest_peak ORDER BY num_users DESC LIMIT 1");
$hprow = mysql_fetch_array($hpsql);
		$sqlhp  = mysql_query( "SELECT * FROM cp_highest_peak ORDER BY num_users DESC LIMIT 1" );
		$sqlhprow = mysql_fetch_array($sqlhp);

?>
<p style="font-size:12px; font-weight:bolder;" align="center">
<?php echo $hprow['num_users']; ?>
</p>
