<?php if (!defined('FLUX_ROOT')) exit; ?>
<table width="100%" border="0" style="font-size:10px; text-align:center; margin-bottom:15px; margin-top:2px;">
  <tr>
    <td align="center">Malaysia</td>
    <td align="center">GMT + 6:00</td>
  </tr>
</table>
<table width="100%" border="0" style="font-size:10px; text-align:center; margin-bottom:13px;">
  <tr>
    <td align="left">Mon-Tue</td>
    <td align="right">8:00PM - 9:00PM</td>
  </tr>
 </table>
 <table width="100%" border="0" style="font-size:10px; text-align:center; margin-bottom:13px;">
  <tr>
    <td align="left">Wed-Thu</td>
    <td align="right">8:00PM - 9:00PM</td>
  </tr>
</table>
<table width="100%" border="0" style="font-size:10px; text-align:center">
  <tr>
    <td align="left">Fri-Sat</td>
    <td align="right">8:00PM - 9:00PM</td>
  </tr>
</table>