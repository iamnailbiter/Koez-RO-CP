<?php if (!defined('FLUX_ROOT')) exit; ?>
<div id="sliderFrame">
        <div id="slider">
                <img src="<?php echo $this->themePath('img/slider1.jpg'); ?>" />

            <img src="<?php echo $this->themePath('img/slider2.jpg'); ?>" />

            <img src="<?php echo $this->themePath('img/slider3.jpg'); ?>"  />
        </div>
    </div>