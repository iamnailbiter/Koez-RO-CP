<?php if (!defined('FLUX_ROOT')) exit; 

if($params->get('action') == 'login')
    {
        $chars = array();
        $guilds = array();
        $sex = array();
        $bsex = array();
		$bclass = array();
    }  else {
		$sex = "<img src='".$this->themePath('img/potm/M/0.gif')."' alt=\"Sex\"/>";
		$sqlpvp  = "SELECT pvpladder.name AS char_name, pvpladder.kills AS kills, pvpladder.deaths AS deaths, char.char_id, char.class AS bclass, login.sex, guild.name as gname 
					FROM pvpladder
					LEFT JOIN  `char` ON pvpladder.char_id = char.char_id
					LEFT JOIN  `login` ON char.account_id = login.account_id
					LEFT JOIN  `guild` ON char.guild_id = guild.guild_id
					ORDER BY kills DESC 
					LIMIT 1";
		$sthpvp  = $server->connection->getStatement($sqlpvp);
		$sthpvp->execute();
		$chars = $sthpvp->fetchAll();
		
		if (empty($chars[0]->sex)) {
			$bsex = $chars[0]->sex;
			$bclass = $chars[0]->bclass;
			$sex = "<img src='".$this->themePath('./img/potm/'.$bsex.'/'.$bclass.'.gif')."' alt=\"Sex\"/>";
		} else {
			$bsex = array();
			$bclass = array();
		}

	}
	?>
<?php if ( $params->get('action') != 'login' ): ?>

		<div id="pvpking" style="position:absolute; margin-top:3px; margin-left:-5px;">
			<?php  if ( empty($chars[0]->char_name) ): ?>
				<table cellspacing="0" cellpadding="0" class="ranking" width="180px" border="0" style="margin-left:-12px;">
					<tr><td class="sex"><?php echo $sex; ?></td></tr>
					</table>
					<table border="0" class="ranking" width="100px" style="margin-left:65px; margin-top:15px; border:none">
					<tr><td style="color:#000"><?php echo htmlspecialchars(substr($chars[0]->char_name,0, 12)) ?></td></tr>
					</table>
					<table border="0" class="ranking" width="100px" style="margin-left:65px; margin-top:10px; border:none">
					<tr><td style="color:#000"><?php echo number_format($chars[0]->kills) ." / ". number_format($chars[0]->deaths) ?></td></tr>
				</table>
			<?php endif; ?>
		</div>
<?php endif; ?>