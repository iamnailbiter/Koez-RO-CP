<?php if (!defined('FLUX_ROOT')) exit; ?>
<?php
if($params->get('action') == 'login')
    {
        $chars = array();
        $guilds = array();
     }  else {
		$sqlgvg  = "SELECT g.guild_id, g.name AS gname, g.emblem_len, (
					SELECT COUNT( c.castle_id ) 
					FROM guild_castle c
					WHERE c.guild_id = g.guild_id
					) AS castles, g.master, ( 
					SELECT COUNT( char_id ) 
					FROM  `char` 
					WHERE  `char`.guild_id = g.guild_id
					) AS members 
					FROM guild AS g 
					LEFT JOIN  `char` AS ch ON ch.char_id = g.char_id 
					LEFT JOIN login ON login.account_id = ch.account_id 
					ORDER BY castles DESC, members DESC , g.max_member DESC , g.next_exp ASC 
					LIMIT 1";
		$sthgvg  = $server->connection->getstatement($sqlgvg);
		$sthgvg->execute();
		$guilds = $sthgvg->fetchall();
	}
	?>
<?php if ( $params->get('action') != 'login' ): ?>
<?php if(empty($guilds[0]->gname)): ?>
							<div style="float:left; margin-left:8px; width:50px; height:80px; border:none">
							<?php if ($guilds[0]->emblem_len): ?>
							<table width="100%" border="0" style="margin-left:10px; margin-top:25px;">
  								<tr>
   									<td><img width="24" src="<?php echo $this->emblem($guilds[0]->guild_id) ?>" />
										<?php else: ?>
										<b>No Emblem</b>
										<?php endif ?>
									</td>
  								</tr>
							</table>
							<?php endif ?>
							</div>
							<div style="float:left; margin-left:15px; width:100px; height:80px; border:none">
							<table width="100%" border="0" style="margin-top:20px;">
  								<tr>
    								<td style="font-weight:normal; font-size:10px;" align="center">
									<?php echo htmlspecialchars(substr($guilds[0]->gname,0 ,15)) ?>
									</td>
  								</tr>
							</table>
							<table width="100%" border="0" style="margin-top:13px;">
  								<tr>
    								<td style="font-weight:normal; font-size:10px;" align="center">
									<?php echo htmlspecialchars(substr($guilds[0]->master,0 ,15)) ?>
									</td>
  								</tr>
							</table>
							</div>
<?php endif; ?>