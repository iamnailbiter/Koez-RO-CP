<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2 style="color:#000">Staff Information</h2>

<div class="panelcontent-1"> <!--do not remove this -->

Path : themes/default/main/staff.php

<h4 style="color:#FF00CC"> Zhao Fu Chow </h4>
<p style="color:#000000">
GM Position : Admininstrator
<br />
Position : Developer / Designer / Scripter / Web Developer<br />
Playing RO since : 2002<br />
Background : Excellent in Scripting any progamming languages, have a logical mind set, Excellent in Designing.<br /><br />
<h4 style="color:#FF00CC"> Zhao Fu Chow </h4>
<p style="color:#000000">
GM Position : Co - Admin
<br />
Position : Event Coordinator / Police / Global Moderator<br />
Playing RO since : 2005<br />
Background : Can handle any issues and easy to approach.<br />
<h4 style="color:#FF00CC"> Zhao Fu Chow </h4>
<p style="color:#000000">
GM Position : Co - Admin
<br />
Position : Event Coordinator / Tester<br />
Playing RO since : 2002<br />
Background : Expert in Bugs Issues with accurate information.<br />
<h2 style="color:#000000">Note</h2>
<p style="color:#000000">
 Admins and Co-Admin in RONAME Ragnarok Online are dedicated and Professionals.
</div>