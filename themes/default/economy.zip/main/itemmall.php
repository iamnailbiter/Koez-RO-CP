<?php if (!defined('FLUX_ROOT')) exit; ?>
<div class="contentitemmall">
<table border="0">
  <tr>
    <td align="center"><img src="<?php echo $this->themePath('img/itemmall/1.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
    <td align="center"><img src="<?php echo $this->themePath('img/itemmall/2.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
    <td align="center"><img src="<?php echo $this->themePath('img/itemmall/3.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
    <td align="center"><img src="<?php echo $this->themePath('img/itemmall/4.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
	<td align="center"><img src="<?php echo $this->themePath('img/itemmall/5.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
    <td align="center"><img src="<?php echo $this->themePath('img/itemmall/6.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
    <td align="center"><img src="<?php echo $this->themePath('img/itemmall/7.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
    <td align="center"><img src="<?php echo $this->themePath('img/itemmall/8.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
    <td align="center"><img src="<?php echo $this->themePath('img/itemmall/9.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
	<td align="center"><img src="<?php echo $this->themePath('img/itemmall/10.bmp'); ?>" title="Item Name<br>Price :100USD" /></td>
  </tr>
</table>

</div>