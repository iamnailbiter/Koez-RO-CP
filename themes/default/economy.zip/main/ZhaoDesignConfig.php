<?php
return array(
	// Server Name
		'serverName'	=> 'Onigiri Ragnarok Online',
		
	// Rate my server link
		'rms' 		=> 'http://ratemyserver.net/index.php?page=detailedlistserver&preview=1&serid=17994&url_sname=Onigiri%20Ragnarok%20Online%20-%20RE',
		
	// Forums link here
		'forum' 	=> 'http://onigiri-gamers.com/forum/',
		
	// Facebook page link here.
		'facebook-page' => 'https://www.facebook.com/onigiriragnarokonlineREmalaysia',
	
)
?>