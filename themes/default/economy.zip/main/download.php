<?php if (!defined('FLUX_ROOT')) exit; ?>

<h2 style="color:#000">Download The Installer</h2>

<div class="panelcontent-1"> <!--do not remove this -->

Path : themes/default/main/download.php

</div><!--do not remove this -->