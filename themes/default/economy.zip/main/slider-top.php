<?php if (!defined('FLUX_ROOT')) exit; ?>
<div id="topslider" style="border:none; width:481px; height:351px; margin-top:0px; margin-left:290px; position:absolute;">

<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="481" height="351">
  <param name="movie" value="<?php echo $this->themePath('img/particles.swf'); ?>" />
  <param name="quality" value="high" />
  <embed src="<?php echo $this->themePath('img/particles.swf'); ?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="481" height="351"></embed>
</object>



</div>