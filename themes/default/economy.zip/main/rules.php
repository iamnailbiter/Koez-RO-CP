<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2 style="color:#000">Server Rules and Regulations</h2>

<div class="panelcontent-1"> <!--do not remove this -->

Path : themes/default/main/rules.php

<p>Base Exp: 10000x  </p>
<p>Job Exp: 10000x</p>
<p>Drop Rate: 5000x</p>
<p> Quest Exp: 10000x</p>
<p>Equip Drop: 10000x</p>
<p>Card Drop: 3000x</p>
<p>MVP Equip Drop: 5000x</p>
<p>MVP Card Drop: 500x</p>
<p>Max Base Lvl: 255</p>
<p>Max Job Lvl: 120</p>
<p>Max Stats: 199</p>
<p>Max ASPD: 195</p>
<p>Server Mode: Normal</p>
<p>Language: German | English</p>
<p>Job Exp: 10000x</p>
<p>Drop Rate: 5000x</p>
<p> Quest Exp: 10000x</p>
<p>Equip Drop: 10000x</p>
<p>Card Drop: 3000x</p>
<p>MVP Equip Drop: 5000x</p>
<p>MVP Card Drop: 500x</p>
<p>Max Base Lvl: 255</p>
<p>Max Job Lvl: 120</p>
<p>Max Stats: 199</p>
<p>Max ASPD: 195</p>
<p>Server Mode: Normal</p>
<p>Language: German | English</p>
<p>Job Exp: 10000x</p>
<p>Drop Rate: 5000x</p>
<p> Quest Exp: 10000x</p>
<p>Equip Drop: 10000x</p>
<p>Card Drop: 3000x</p>
<p>MVP Equip Drop: 5000x</p>
<p>MVP Card Drop: 500x</p>
<p>Max Base Lvl: 255</p>
<p>Max Job Lvl: 120</p>
<p>Max Stats: 199</p>
<p>Max ASPD: 195</p>
<p>Server Mode: Normal</p>
<p>Language: German | English</p>
<p>Job Exp: 10000x</p>
<p>Drop Rate: 5000x</p>
<p> Quest Exp: 10000x</p>
<p>Equip Drop: 10000x</p>
<p>Card Drop: 3000x</p>
<p>MVP Equip Drop: 5000x</p>
<p>MVP Card Drop: 500x</p>
<p>Max Base Lvl: 255</p>
<p>Max Job Lvl: 120</p>
<p>Max Stats: 199</p>
<p>Max ASPD: 195</p>
<p>Server Mode: Normal</p>
<p>Language: German | English</p>
<p>Job Exp: 10000x</p>
<p>Drop Rate: 5000x</p>
<p> Quest Exp: 10000x</p>
<p>Equip Drop: 10000x</p>
<p>Card Drop: 3000x</p>
<p>MVP Equip Drop: 5000x</p>
<p>MVP Card Drop: 500x</p>
<p>Max Base Lvl: 255</p>
<p>Max Job Lvl: 120</p>
<p>Max Stats: 199</p>
<p>Max ASPD: 195</p>
<p>Server Mode: Normal</p>
<p>Language: German | English</p>
</div>