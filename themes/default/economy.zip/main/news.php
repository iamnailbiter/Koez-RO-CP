<?php if (!defined('FLUX_ROOT')) exit; ?> 

	<div class="innerneu" style="float:left; width:300px; height:200px; border:none; margin-left:200px; margin-top:70px; position:absolute; overflow-x:hidden;">

<?php
if ( $enablerss ):
require_once("rsslib.php");
echo RSS_Display($news, 10);
endif;
?>

	</div>