<?php if (!defined('FLUX_ROOT')) exit; ?>
<?php $ZhaoDesign = include('main/ZhaoDesignConfig.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<?php if (isset($metaRefresh)): ?>
		<meta http-equiv="refresh" content="<?php echo $metaRefresh['seconds'] ?>; URL=<?php echo $metaRefresh['location'] ?>" />
		<?php endif ?>
		<title><?php echo Flux::config('SiteTitle'); if (isset($title)) echo ": $title" ?></title>
		<link rel="stylesheet" href="<?php echo $this->themePath('css/flux.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $this->themePath('css/style.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link href="<?php echo $this->themePath('css/flux/unitip.css') ?>" rel="stylesheet" type="text/css" media="screen" title="" charset="utf-8" />		<?php if (Flux::config('EnableReCaptcha')): ?>
		<link href="<?php echo $this->themePath('css/flux/recaptcha.css') ?>" rel="stylesheet" type="text/css" media="screen" title="" charset="utf-8" />
		<?php endif ?>
		<!--[if IE]>
		<link rel="stylesheet" href="<?php echo $this->themePath('css/flux/ie.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<![endif]-->	
		<!--[if lt IE 7]>
		<script src="<?php echo $this->themePath('js/ie7.js') ?>" type="text/javascript"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.unitpngfix.js') ?>"></script>
		<![endif]-->
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery-1.7.1.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.datefields.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.unitip.js') ?>"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.money-input').keyup(function() {
					var creditValue = parseInt($(this).val() / <?php echo Flux::config('CreditExchangeRate') ?>, 10);
					if (isNaN(creditValue))
						$('.credit-input').val('?');
					else
						$('.credit-input').val(creditValue);
				}).keyup();
				$('.credit-input').keyup(function() {
					var moneyValue = parseFloat($(this).val() * <?php echo Flux::config('CreditExchangeRate') ?>);
					if (isNaN(moneyValue))
						$('.money-input').val('?');
					else
						$('.money-input').val(moneyValue.toFixed(2));
				}).keyup();
				processDateFields();
			});
			function reload(){
				window.location.href = '<?php echo $this->url ?>';
			}
			$(document).ready(function(){
				$('#tabs div').hide();
				$('#tabs div:first').show();
				$('#tabs ul li:first').addClass('active');
				$('#tabs ul li a').click(function(){ 
				$('#tabs ul li').removeClass('active');
				$(this).parent().addClass('active'); 
				var currentTab = $(this).attr('href'); 
				$('#tabs div').hide();
				$(currentTab).show();
				return false;
				});
			});
			$(document).ready(function(){
				$('#tabs1 div').hide();
				$('#tabs1 div:first').show();
				$('#tabs1 ul li:first').addClass('active');
				$('#tabs1 ul li a').click(function(){ 
				$('#tabs1 ul li').removeClass('active');
				$(this).parent().addClass('active'); 
				var currentTab = $(this).attr('href'); 
				$('#tabs1 div').hide();
				$(currentTab).show();
				return false;
				});
			});
		</script>
		<script type="text/javascript">
			function updatePreferredServer(sel){
				var preferred = sel.options[sel.selectedIndex].value;
				document.preferred_server_form.preferred_server.value = preferred;
				document.preferred_server_form.submit();
			}
			var spinner = new Image();
			spinner.src = '<?php echo $this->themePath('img/spinner.gif') ?>';
			function refreshSecurityCode(imgSelector){
				$(imgSelector).attr('src', spinner.src);
				var clean = <?php echo Flux::config('UseCleanUrls') ? 'true' : 'false' ?>;
				var image = new Image();
				image.src = "<?php echo $this->url('captcha') ?>"+(clean ? '?nocache=' : '&nocache=')+Math.random();
				
				$(imgSelector).attr('src', image.src);
			}
			function toggleSearchForm()
			{
				$('.search-form').slideToggle('fast');
			}
		</script>
		
		<?php if (Flux::config('EnableReCaptcha') && Flux::config('ReCaptchaTheme')): ?>
		<script type="text/javascript">
			 var RecaptchaOptions = {
			    theme : '<?php echo Flux::config('ReCaptchaTheme') ?>'
			 };
		</script>
		<?php endif ?>
		
	</head>
	<body>
		<div id="wrapper">
			<div id="main">
<div class="statusserver" style="margin-left:170px; width:700px; height:50px; position:absolute; float:left; border:none; ">
<?php include('main/status.php'); ?>
</div>
<?php include('main/slider-top.php'); ?>
				<div class="spacer">
				
<div style=" margin-left:360px; margin-top:100px; width:350px; height:80px; position:absolute;">
<img src="<?php echo $this->themePath('img/logo.png'); ?>" />
</div>
				</div>				
			<div id="menu">
<div style="margin-left:120px; margin-top:138px; width:50px; height:20px; position:absolute; float:left; border:none; ">
<table border="0" width="50px">
<tr>
<td align="center" style="opacity:0.5;"><?php include('main/highest_peak.php'); ?>
</td>
</tr>
</table>
</div>
			<div style="height:105px; position:absolute; border:none">
			<table width="350px" border="0">
  <tr>
    <td align="left"><a href="<?php echo $this->url('main','download'); ?>"><img src="<?php echo $this->themePath('img/download.png'); ?>" onmouseover='this.src="<?php echo $this->themePath('img/download_hover.png'); ?>"' onmouseout='this.src="<?php echo $this->themePath('img/download.png'); ?>"'  /></a></td>
	<td align="right"><a href="<?php echo $this->url('account','create'); ?>"><img src="<?php echo $this->themePath('img/reg.png'); ?>" onmouseover='this.src="<?php echo $this->themePath('img/reg_hover.png'); ?>"' onmouseout='this.src="<?php echo $this->themePath('img/reg.png'); ?>"'  /></a></td>
  </tr>
</table>
			</div>
				</div>
				<div class="main-cont">
						<div class="sidebarleft">
				
							<div class="quicklinks">
								<ul>
								<li>
<a href="<?php echo $this->url('main','rules'); ?>"><img src="<?php echo $this->themePath('img/rules.png'); ?>" onmouseover='this.src="<?php echo $this->themePath('img/rules_hover.png'); ?>"' onmouseout='this.src="<?php echo $this->themePath('img/rules.png'); ?>"'  /></a>
								</li>
								<li>
<a href="<?php echo $this->url('main','info'); ?>"><img src="<?php echo $this->themePath('img/info.png'); ?>" onmouseover='this.src="<?php echo $this->themePath('img/info_hover.png'); ?>"' onmouseout='this.src="<?php echo $this->themePath('img/info.png'); ?>"'  /></a>
								</li>	
								<li>
<a href="<?php echo $this->url('main','staff'); ?>"><img src="<?php echo $this->themePath('img/staff.png'); ?>" onmouseover='this.src="<?php echo $this->themePath('img/staff_hover.png'); ?>"' onmouseout='this.src="<?php echo $this->themePath('img/staff.png'); ?>"'  /></a>
								</li>	
								<li>
<a href="<?php echo $ZhaoDesign['forum']; ?>"><img src="<?php echo $this->themePath('img/forum.png'); ?>" onmouseover='this.src="<?php echo $this->themePath('img/forum_hover.png'); ?>"' onmouseout='this.src="<?php echo $this->themePath('img/forum.png'); ?>"'  /></a>
								</li>	
								<li>
<a href="<?php echo $this->url('vote'); ?>"><img src="<?php echo $this->themePath('img/vote.png'); ?>" onmouseover='this.src="<?php echo $this->themePath('img/vote_hover.png'); ?>"' onmouseout='this.src="<?php echo $this->themePath('img/vote.png'); ?>"'  /></a>
								</li>	
								<li>
<a href="<?php echo $ZhaoDesign['rms']; ?>"><img src="<?php echo $this->themePath('img/review.png'); ?>" onmouseover='this.src="<?php echo $this->themePath('img/review_hover.png'); ?>"' onmouseout='this.src="<?php echo $this->themePath('img/review.png'); ?>"'  /></a>
								</li>	

								</ul>
							</div>
							<div class="fb-page">
							<?php include ('main/fbpage.php'); ?>
							</div>
						</div>
						
					<div class="sidebarright">
						<div class="controlpanel"><?php include('main/loginpanel.php') ?></div>
						<div class="halloffame">
						<?php include ('main/halloffame.php'); ?>
						</div>
						<div class="woeschedule">	
						<?php include ('main/woesched.php'); ?>
						</div>
						<div class="bestguild" style="border:none; width:180px; height:80px; position:absolute; margin-left:10px; margin-top:143px;">
							<?php include ('main/topguild.php'); ?>
						</div>
					</div>	
					<div class="containerbgtop"></div>
					<div class="containerbginner">
					<div class="centercontent">
							<div class="centercont">
								<?php if ($message=$session->getMessage()): ?>
									<p class="message"><?php echo htmlspecialchars($message) ?></p>
								<?php endif ?>
								<?php include 'main/submenu.php' ?>
								<?php include 'main/pagemenu.php' ?>
								<?php if (in_array($params->get('module'), array('donate', 'purchase'))) include 'main/balance.php' ?>